import React, { useEffect, useState } from "react";
import ContactCard from "./ContactCard";

const ContactList = (props) => {
  const [users, setUsers] = useState([]);
  const [id, setId] = useState(''); // Fix: Changed useEffect to useState

  useEffect(() => {
    const usersData = localStorage.getItem("users");
    if (usersData) {
      setUsers(JSON.parse(usersData));
    }
  }, []);

  const handleDelete = (id) => {
    const updatedUsers = users.filter((user) => user.id !== id);
    setUsers(updatedUsers);
  }

  return (
    <div className="ui celled list">
      {users.map((user) => (
        <ContactCard user={user} key={user.id} setId={setId} handleDelete={handleDelete} />
      ))}
    </div>
  );
};

export default ContactList;
