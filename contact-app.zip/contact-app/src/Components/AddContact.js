import React, { useEffect, useState } from "react";
import { v4 as uuid } from "uuid";

const AddContact = () => {
  const [user, setUser] = useState({
    id: "",
    name: "",
    Email: "",
  });

  const [users, setUsers] = useState([]);

  useEffect(() => {
    localStorage.setItem("users", JSON.stringify(users));
  }, [users]);

  const add = (e) => {
    e.preventDefault();
    const newUser = { ...user, id: uuid() };
    setUsers([...users, newUser]);
  };

  const saveEmail = (e) => {
    const newUser = { ...user, Email: e.target.value };
    setUser(newUser);
  };

  const saveName = (e) => {
    const newUser = { ...user, name: e.target.value };
    setUser(newUser);
  };

  const { name, Email } = user;

  return (
    <div className="ui main">
      <h2>Add Contact</h2>
      <form className="ui form" onSubmit={add}>
        <div className="field">
          <label>Name:</label>
          <input
            type="text"
            name="name"
            placeholder="Enter your name"
            value={name}
            onChange={saveName}
          />
        </div>
        <div className="field">
          <label>Email id:</label>
          <input
            type="email"
            name="email"
            placeholder="Enter your email id"
            value={Email}
            onChange={saveEmail}
          />
        </div>
        <button className="ui button blue" type="submit">
          Add
        </button>
      </form>
    </div>
  );
};

export default AddContact;
