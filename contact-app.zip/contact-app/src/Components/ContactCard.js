import React from "react";
import user from "../Images/user.png"

const ContactCard = (props) =>{

    const {id,name,Email,handleDelete} = props.user;
    return(
        <div className="item">
            <div className="content">
                 <img className="ui avatar image" src={user} alt="user"/>
                <div className="header">{name}</div>
                <div className="header">{Email}</div>
                <div>
                    <button onClick = { () => handleDelete(id)}> Delete</button>
                </div>
            </div>
        </div>
    );

}

export default ContactCard;